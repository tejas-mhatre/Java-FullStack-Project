package com.example.railway;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RailwayReservationApplicationTests {

	@Test
	void contextLoads() {
	}

}
